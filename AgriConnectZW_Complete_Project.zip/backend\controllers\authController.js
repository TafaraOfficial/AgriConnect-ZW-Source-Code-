const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

exports.register = async(req,res)=>{

    try{

        const {fullName,email,password,role} = req.body;

        const userExists = await User.findOne({email});

        if(userExists){
            return res.status(400).json({
                message:"User already exists"
            });
        }

        const hashedPassword =
        await bcrypt.hash(password,10);

        const user = await User.create({
            fullName,
            email,
            password:hashedPassword,
            role
        });

        res.status(201).json(user);

    }catch(error){

        res.status(500).json({
            error:error.message
        });
    }
}

exports.login = async(req,res)=>{

try{

const {email,password} = req.body;

const user =
await User.findOne({email});

if(!user){
return res.status(404).json({
message:"User not found"
});
}

const valid =
await bcrypt.compare(
password,
user.password
);

if(!valid){
return res.status(401).json({
message:"Invalid credentials"
});
}

const token = jwt.sign(
{
id:user._id,
role:user.role
},
process.env.JWT_SECRET,
{
expiresIn:"7d"
}
);

res.json({
token,
user
});

}catch(error){

res.status(500).json({
error:error.message
});
}
};